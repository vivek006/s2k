<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>

<link href="<?php echo base_url()."assets/admin/"; ?>bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">

<!-- MetisMenu CSS -->
<link href="<?php echo base_url()."assets/admin/"; ?>metisMenu/dist/metisMenu.min.css" rel="stylesheet">

<!-- Timeline CSS -->
<link href="<?php echo base_url()."assets/admin/"; ?>css/timeline.css" rel="stylesheet">

<!-- Custom CSS -->
<link href="<?php echo base_url()."assets/admin/"; ?>css/sb-admin-2.css" rel="stylesheet">

<!-- Morris Charts CSS -->
<link href="<?php echo base_url()."assets/admin/"; ?>morrisjs/morris.css" rel="stylesheet">

<!-- Custom Fonts -->
<link href="<?php echo base_url()."assets/admin/"; ?>font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

<!-- Custom CSS -->
<link href="<?php echo base_url()."assets/admin/"; ?>css/custom.css" rel="stylesheet">