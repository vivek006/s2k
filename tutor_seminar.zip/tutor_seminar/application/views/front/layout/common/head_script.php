<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0 maximum-scale=1.0, user-scalable=0">

<!-- MATERIAL CSS -->

<link href="<?php echo base_url()."assets/front/"; ?>css/materialize.min.css" rel="stylesheet">
<!-- MATERIAL-ICONS -->
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

<!-- RESPONSIVE CSS -->

<link href="<?php echo base_url()."assets/front/"; ?>css/font-awesome.min.css" rel="stylesheet">
<!-- NEW CSS -->

<link href="<?php echo base_url()."assets/front/"; ?>css/new.css" rel="stylesheet">
<!-- RESPONSIVE CSS -->

<link href="<?php echo base_url()."assets/front/"; ?>css/responsive.css" rel="stylesheet">
<!--[if lt IE 9]>
<script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
<![endif]-->




