<section class="home-banner">
  <div class="container">
    <div class="row">
      <div class="col s8 s8">
        <div class="head-line">
          <h2  class="white-text lighten-2">Hunger for good programming skills,<br>We are here to help you</h2>
          <p class="white-text lighten-6">Deliver Nature brings professional and student at one place, we are growing team of 40+ professional from all major city of india.</p>
        </div>
      </div>
      <img src="<?php echo base_url()."assets/front/"; ?>img/Capturenrew.png" alt="">
    </div>
  </div>
</section>