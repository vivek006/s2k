<!-- JQUERY -->
<script src="<?php echo base_url()."assets/front/"; ?>js/jquery-2.1.4.min.js"></script>
<!-- MATERIAL JS -->

<script src="<?php echo base_url()."assets/front/"; ?>js/materialize.min.js"></script>
<!-- CUSTOM JS -->

<script src="<?php echo base_url()."assets/front/"; ?>js/custom.js"></script>