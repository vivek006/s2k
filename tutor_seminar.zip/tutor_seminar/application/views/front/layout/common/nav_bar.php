<nav>
  <div class="container">
    <div class="nav-wrapper">
      <a href="index.php" class="brand-logo" ><img style='width:42 px !importanr; height:42 px !importanr;'  src="<?php echo base_url()."assets/front/"; ?>img/myownlogo.PNG" alt=""></a>
      <a href="#" data-activates="mobile-demo" class="button-collapse"><i class="material-icons">menu</i></a>
      <ul class="right hide-on-med-and-down">
        <li><a href="index.php">Home</a></li>
        <li><a href="#who-we-are" class="jumper">About</a></li>
        <li><a href="#services" class="jumper">Services</a></li>
        <li><a href="#contact" class="jumper">Contact</a></li>
        <li><a href="<?php echo base_url();?>agency"class="active">Login</a></li>
      </ul>
      <ul class="side-nav" id="mobile-demo">
        <li><a href="#home">Home</a></li>
        <li><a href="#who-we-are">About</a></li>
        <li><a href="#services">Services</a></li>
        <li><a href="#contact">Contact</a></li>
        <li><a href="login.php">Login</a></li>
      </ul>
    </div>
  </div> 
</nav>