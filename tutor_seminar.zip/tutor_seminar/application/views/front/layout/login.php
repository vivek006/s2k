<!DOCTYPE>
<html>
<head>
<title>ATM-Audit Login</title>
<?php require_once 'common/head-script.php';?>
</head>
<body>
	<?php require_once 'common/nav-bar.php';?>
	<?php require_once 'login/content.php';?>
	<?php require_once 'common/footer.php';?>
	<?php require_once 'common/body-script.php';?>
</body>
</html>