<!DOCTYPE>
<html>
<head>
<title>ATM-Audit FAQ</title>
<?php require_once 'common/head-script.php';?>
</head>
<body>
	<?php require_once 'common/nav-bar.php';?>
	<?php require_once 'faq/content.php';?>
	<?php require_once 'common/footer.php';?>
	<?php require_once 'common/body-script.php';?>
</body>
</html>